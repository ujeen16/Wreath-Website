function message(){
    var name = document.getElementById('name');
    var email = document.getElementById('email');
    var msg = document.getElementById('msg');
    var subject = document.getElementById('subject');
    const success = document.getElementById('success');
    const danger = document.getElementById('danger');

    // user may only send a message after timeout delay and message is done displaying
    send.style.pointerEvents = 'none';
    send.style.cursor = 'not-allowed';
    // display appropriate message
    if(name.value === '' || email.value === '' || msg.value === ''){
        danger.style.display = 'block';
    }
    else{
        // if success remove text 
        name.value = '';
        email.value = '';
        msg.value = '';
        subject.value = '';
        success.style.display = 'block';
    }


    setTimeout(() => {
        danger.style.display = 'none';
        success.style.display = 'none';
        send.style.pointerEvents = 'auto';
        send.style.cursor = 'pointer';
    }, 4000);

}